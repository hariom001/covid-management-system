<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Covid-19 Testing Management System</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/scrolling-nav.css" rel="stylesheet">










  <style>
.mySlides {display:none;}


/*-------------footer----*/
.footer {
  padding-bottom: 10px;
  background-color:darkgray;
}

.footer .copyright a {
  font-weight: 600;
}

.lh-35 {
  line-height: 35px;
}

.logo {
  font-weight: 600;
  letter-spacing: 1px;
}

.logo h3 {
  color: #223a66;
}

.logo span {
  color: #223a66;
}

.widget .divider {
  height: 3px;
}

.widget h4 {
  color: #223a66;
}

.widget .footer-menu a {
  color: #6F8BA4;
}

.widget .footer-menu a:hover {
  color: #e12454;
}

.footer-contact-block span {
  font-weight: 400;
  color: #6F8BA4;
}

.footer-contact-block i {
  font-size: 20px;
}

.footer-btm {
  border-top: 1px solid rgba(0, 0, 0, 0.06);
}

.footer-socials li a {
  width: 45px;
  height: 45px;
  background: #6F8BA4;
  color: #fff;
  display: inline-block;
  text-align: center;
  border-radius: 100%;
  padding-top: 12px;
}

.widget-contact h6 {
  font-weight: 500;
  margin-bottom: 18px;
}

.widget-contact h6 i {
  color: #e12454;
}

.subscribe {
  position: relative;
}

.subscribe .form-control {
  border-radius: 50px;
  height: 60px;
  padding-left: 25px;
  border-color: #eee;
}

.subscribe .btn {
  position: absolute;
  right: 6px;
  top: 6px;
}

.backtop {
  position: fixed;
  background: #e12454;
  z-index: 9999;
  display: inline-block;
  right: 55px;
  width: 60px;
  height: 60px;
  bottom: 50px;
  text-align: center;
  display: flex;
  justify-content: center;
  align-items: center;
  opacity: 0;
  border-radius: 50px;
}

.backtop i {
  color: #fff;
  font-size: 20px;
}

.reveal {
  transition: all .3s;
  cursor: pointer;
  opacity: 1;
}
/*-------social icons-------*/
.fa {
  padding: 20px;
  font-size: 30px;
  width: 30px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
  border-radius: 50%;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}

.fa-pinterest {
  background: #cb2027;
  color: white;
}

.fa-snapchat-ghost {
  background: #fffc00;
  color: white;
  text-shadow: -1px 0 black, 0 1px black, 1px 0 black, 0 -1px black;
}

.fa-skype {
  background: #00aff0;
  color: white;
}

.fa-android {
  background: #a4c639;
  color: white;
}

.fa-dribbble {
  background: #ea4c89;
  color: white;
}

.fa-vimeo {
  background: #45bbff;
  color: white;
}

.fa-tumblr {
  background: #2c4762;
  color: white;
}

.fa-vine {
  background: #00b489;
  color: white;
}

.fa-foursquare {
  background: #45bbff;
  color: white;
}

.fa-stumbleupon {
  background: #eb4924;
  color: white;
}

.fa-flickr {
  background: #f40083;
  color: white;
}

.fa-yahoo {
  background: #430297;
  color: white;
}

.fa-soundcloud {
  background: #ff5500;
  color: white;
}

.fa-reddit {
  background: #ff5700;
  color: white;
}

.fa-rss {
  background: #ff6600;
  color: white;
}








</style>

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">Covid-19</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#about">About Coronavirus </a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#services">Covid-19 Symptoms</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#contact">Prevention</a>
          </li>
  <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="new-user-testing.php">Testing</a>
          </li>
           <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="live-test-updates.php">Live Updates</a>
          </li>

           <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="login.php">Admin</a>
          </li>


        </ul>
      </div>
    </div>
  </nav>

  
 <!-- <header class="bg-primary text-black">     -->
 <h2 class="w3-center">Automatic Slideshow</h2>

<div class="w3-content w3-section" style="max-width:auto; height:400px;">
  <
  <img class="mySlides" src="img\download7.jpg" style="width:100%; height:400px;">
  <img class="mySlides" src="img\download9.png" style="width:100%; height:400px;">
  <img class="mySlides" src="img\download3.jpg" style="width:100%; height:400px;">
  <img class="mySlides" src="img\download2.jpg" style="width:100%; height:400px;">
  <img class="mySlides" src="img\download10.png" style="width:100%; height:400px;">
  <img class="mySlides" src="img\download5.jpg" style="width:100%; height:400px;">
  <img class="mySlides" src="img\download6.jpg" style="width:100%; height:400px;">
  <img class="mySlides" src="img\download11.jpg" style="width:100%; height:400px;">
  <img class="mySlides" src="img\download8.jpg" style="width:100%; height:400px;">
</div></br></br>
    <div class="container text-center">
      <h1><u>Covid-19</u></h1>
    </div>
 <!-- </header>       -->
<!--
  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>About this page</h2>
          <p class="lead">Coronavirus disease (COVID-19) is an infectious disease caused by a newly discovered coronavirus. Most people infected with the COVID-19, virus will experience mild to moderate, respiratory illness & recover without requiring special treatment. Older people and those with underlying medical problem like cardiovascular disease.</p>
          <p class="lead">The COVID-19 virus spread primarily through droplet of saliva or discharge from the nose when an infected person coughs or sneezes so it’s important that you also practice respiratory etiquette.</p>
         
        </div>
      </div>
    </div>
  </section>

-->

<!-- Start About us -->
<section id="about">
        <div class="col-lg-8 mx-auto">
  <div id="about" class="about-box">
    <div class="about-a1">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="title-box">
              <h2><font color="black">About</font></h2>
              
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="row align-items-center about-main-info">
              <div class="col-lg-6 col-md-6 col-sm-12">
                <p>Coronavirus disease (COVID-19) is an infectious disease caused by a newly discovered coronavirus. Most people infected with the COVID-19, virus will experience mild to moderate, respiratory illness & recover without requiring special treatment. Older people and those with underlying medical problem like cardiovascular disease.</p>
          <p class="lead">The COVID-19 virus spread primarily through droplet of saliva or discharge from the nose when an infected person coughs or sneezes so it’s important that you also practice respiratory etiquette.. </p>
                <button class="btn">Read More</button>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="about-m">
                  <ul id="banner">
                    <li>
                      <img src="img\download1.jpg" height="300px">
                    </li>
                   
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
     
    </div>
  </section>
  <!-- End About us -->





  <section id="services" class="bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>Covid-19 Symptoms</h2>
          <hr />
<p><strong>Hight Fever 2-14 days!</strong><br />
Reported illnesses have ranged from mild symptoms to severe illness and death</p>
             <hr />
<p><strong>Dry Cough 2-14 days!</strong><br />
Reported illnesses have ranged from mild symptoms to severe illness and death</p>
          <hr />
<p><strong>Shortness of breath!</strong><br />
Reported illnesses have ranged from mild symptoms to severe illness and death</p>
        </div>
      </div>
    </div>
  </section>

  <section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>Prevention</h2>
  <ul>
            <li>Wash your Hands often</li>
            <li>Wear A Face mask</li>
            <li>Avoid contact with sick people</li>
            <li>Always cover your cough or sneeze</li>
          </ul>
        </div>
      </div>
    </div>
  </section>


<!-- footer Start -->
<footer class="footer section gray-bg">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 mr-auto col-sm-6">
        <div class="widget mb-5 mb-lg-0">
          <div class="logo mb-4">
            <img src="images/l1.png" alt="" class="img-fluid">
          </div>
          <p>Tempora dolorem voluptatum nam vero assumenda voluptate, facilis ad eos obcaecati tenetur veritatis eveniet distinctio possimus.</p>

          <ul class="list-inline footer-socials mt-4">
            <li><a href="#" class="fa fa-facebook"></a></li>
            <li><a href="#" class="fa fa-twitter"></a></li>
            <li><a href="#" class="fa fa-google"></a></li>
          </ul>
        </div>
      </div>

      

      <div class="col-lg-2 col-md-6 col-sm-6">
        <div class="widget mb-5 mb-lg-0">
          <h4 class="text-capitalize mb-3">Support</h4>
          <div class="divider mb-4"></div>

          <ul class="list-unstyled footer-menu lh-35">
            <li><a href="#">Terms & Conditions</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Company Support </a></li>
            <li><a href="#">FAQuestions</a></li>
            <li><a href="#">Company Licence</a></li>
          </ul>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="widget widget-contact mb-5 mb-lg-0">
          <h4 class="text-capitalize mb-3">Get in Touch</h4>
          <div class="divider mb-4"></div>

          <div class="footer-contact-block mb-4">
            <div class="icon d-flex align-items-center">
              <i class="icofont-email mr-3"></i>
              <span class="h6 mb-0">Support Available for 24/7</span>
            </div>
            <h4 class="mt-2"><a href="tel:+23-345-67890">Support@email.com</a></h4>
          </div>

          <div class="footer-contact-block">
            <div class="icon d-flex align-items-center">
              <i class="icofont-support mr-3"></i>
              
            </div>
            <h4 class="mt-2"><a href="tel:+23-345-67890">+91 111111111</a></h4>
          </div>
        </div>
      </div>
    </div>
    
    <div class="footer-btm py-4 mt-5">
      <div class="row align-items-center justify-content-between">
        <div class="col-lg-6">
          <div class="copyright">
            &copy; Copyright Reserved to <span class="text-color">Covid-19</span> by <a href="#">Axis Mca Group</a>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="subscribe-form text-lg-right mt-5 mt-lg-0">
            <form action="#" class="subscribe">
              <input type="text" class="form-control" placeholder="Your Email address">
              <a href="#" class="btn btn-main-2 btn-round-full">Subscribe</a>
            </form>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-4">
          <a class="backtop js-scroll-trigger" href="#top">
            <i class="icofont-long-arrow-up"></i>
          </a>
        </div>
      </div>
    </div>
  </div>
</footer>




  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="js/scrolling-nav.js"></script>
  <script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>



</body>

</html>
